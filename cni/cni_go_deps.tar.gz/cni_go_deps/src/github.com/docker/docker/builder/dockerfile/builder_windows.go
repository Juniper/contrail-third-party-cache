package dockerfile

var defaultShell = []string{"cmd", "/S", "/C"}
